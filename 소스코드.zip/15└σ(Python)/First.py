print("이것이 MySQL이다")
print("파이썬 연동을 학습 중입니다.")
