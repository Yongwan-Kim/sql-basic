
/* 02장 */


-- <실습 1> --

/*
cmd 

SETX PATH "C:\Program Files\MySQL\MySQL Server 8.0\bin;%PATH%" 

shutdown -r -t 0 
*/

-- </실습 1> --



-- <실습 2> --

/*

cmd 

CD \employees 

mysql -u root -p 

source employees.sql ;

show databases ;

exit 

*/

-- </실습 2> --



-- <실습 3> --

-- </실습 3> --

