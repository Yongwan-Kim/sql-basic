<?php
   $str1 = "이것이 MySQL이다<br>";   echo $str1;
   $str2 = 'PHP 프로그래밍<br>';   echo $str2;
   $str3 = "SELECT * FROM userTBL WHERE userID='JYP' ";   echo $str3;
 ?>