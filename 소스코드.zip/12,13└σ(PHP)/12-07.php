<?php
   $jumsu=83;
   
   if($jumsu >= 90) {
	   echo "A학점";
   } elseif($jumsu >= 80) {
	   echo "B학점";
   } elseif($jumsu >= 70) {
	   echo "C학점";
   } elseif($jumsu >= 60) {
	   echo "D학점";
   } else {
	   echo "F학점";
   }
 ?>